jquery-week-calendar
====================

Now actively maintained in the following fork - https://github.com/themouette/jquery-week-calendar
